---
name: defectloop
description: "统一执行代码缺陷扫描、证据化报告、授权修复和修复后复检。用于用户要求检查仓库、Git 改动、目录、文件、函数或代码片段中的缺陷，根据缺陷报告、报错堆栈或 Code Review 意见修改代码，或明确要求先检查再修复时。扫描阶段保持只读；只有用户明确要求修改代码时才进入修复流程。纯格式化、纯重构、需求分析和文档任务不使用此 skill。"
---

# DefectLoop

把扫描与修复作为同一个入口下的两套隔离工作流执行。不得启动子 Agent；根据用户意图读取并遵循包内对应模块。

## 路由请求

- 用户只要求检查、扫描、定位缺陷、提交前审查或修复后复检时，读取 `code-defect-scanner/WORKFLOW.md`，保持只读，不进入修复模块。
- 用户明确要求修复、改代码、应用缺陷报告或落实 Code Review 意见时，读取 `code-defect-fixer/WORKFLOW.md`。没有明确修改意图时不得写文件。
- 用户要求“检查并修复”时，依次执行扫描、修复、复检。扫描报告只把证据充分的发现交给修复模块；`hypothesis` 不得自动修复。
- 用户只要求解释报告、报错或方案时，只做分析，不修改文件。
- 纯格式化、纯重构、需求实现、架构建议或文档任务不执行缺陷工作流。

## 执行闭环

1. 确定用户授权的代码范围和是否包含修改权限。
2. 按意图读取对应模块的 `WORKFLOW.md`，遵守其中的范围、安全边界和完成条件。
3. 扫描时使用 `code-defect-scanner/references/defect-report-schema.json` 输出 `schema_version=1.0` 报告。
4. 修复前使用 `code-defect-fixer/scripts/validate_report.py` 校验报告字段、路径和当前代码证据。证据过期或根因不确定时停止修改。
5. 修复后运行可用的目标测试、编译、lint 或类型检查，并再次执行扫描模块复检已修改范围。
6. 报告实际运行、通过、失败和跳过的验证，不把建议或未执行命令描述为已通过。

## 资源路径

所有模块资源路径都相对于本 Skill 根目录解析。调用报告校验器时使用完整模块路径：

```text
python code-defect-scanner/scripts/validate_report.py <report.json> --source-root <扫描根目录>
python code-defect-fixer/scripts/validate_report.py <report.json> --source-root <项目根目录>
```

两个模块共享相同报告协议，但保持不同权限：

- `code-defect-scanner/`：只读扫描、证据判断与报告生成。
- `code-defect-fixer/`：显式授权后的根因分析、最小修复与验证。

## 完成条件

- 已按用户意图选择正确模块，没有因扫描请求写入代码。
- 已保留用户现有改动，没有访问或修改未授权路径。
- 每个缺陷、修复和验证结论都有当前代码或真实命令结果支持。
- 组合流程已明确报告扫描、修复和复检三个阶段的实际状态。
